// Replace these two placeholders with values from Supabase > Project Settings > API.
// Use the Project URL and the publishable key (or legacy anon key) ONLY.
// Never put the service_role/secret key in browser code.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE";

const configured = SUPABASE_URL.startsWith("https://") &&
  !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const client = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const $ = id => document.getElementById(id);
const show = (id, yes=true) => $(id).classList.toggle("hidden", !yes);
const message = (s) => $("authMessage").textContent = s;

if (configured) show("configNotice", false);

$("signUp").onclick = async () => {
  if (!client) return message("Add your Supabase URL and publishable/anon key in app.js first.");
  const email=$("email").value.trim(), password=$("password").value;
  if (!email || password.length < 8) return message("Enter a valid email and a password of at least 8 characters.");
  const {error}=await client.auth.signUp({email,password});
  message(error ? error.message : "VIP request created. Confirm your email if requested, then wait for administrator approval.");
};
$("signIn").onclick = async () => {
  if (!client) return message("Add your Supabase URL and publishable/anon key in app.js first.");
  const {error}=await client.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});
  if(error) return message(error.message);
  await refreshSession();
};
$("signOut").onclick = async () => { if(client) await client.auth.signOut(); show("appPanel",false); show("authPanel",true); };
async function refreshSession(){
  if(!client) return;
  const {data:{user}}=await client.auth.getUser();
  if(!user){show("appPanel",false);show("authPanel",true);return;}
  show("authPanel",false);show("appPanel",true);
  const {data:profile,error}=await client.from("profiles").select("role,status").eq("id",user.id).single();
  if(error){$("memberStatus").textContent="Could not load profile: "+error.message;return;}
  $("memberStatus").textContent=`Signed in as ${user.email} · ${profile.role} · ${profile.status}`;
  const approved=profile.status==="approved";
  show("pendingNotice",!approved);show("approvedArea",approved);
}
if(client){client.auth.onAuthStateChange(()=>{setTimeout(refreshSession,0)});refreshSession();}

function implied(ids){
  const values=ids.map(id=>Number($(id).value));
  if(values.some(v=>!Number.isFinite(v)||v<=1)) throw new Error("Enter valid decimal odds greater than 1.00 in every field.");
  const raw=values.map(v=>1/v),sum=raw.reduce((a,b)=>a+b,0);
  return raw.map(v=>100*v/sum);
}
$("analyse").onclick=()=>{
  try{
    const names=[$("homeTeam").value.trim(),$("awayTeam").value.trim()];
    if(!names[0]||!names[1]) throw new Error("Enter both team names.");
    const p=implied(["homeOdds","drawOdds","awayOdds"]);
    const g=implied(["overOdds","underOdds"]);
    $("predictionResult").innerHTML=`<strong>${names[0]} vs ${names[1]}</strong><br>Home win: ${p[0].toFixed(1)}%<br>Draw: ${p[1].toFixed(1)}%<br>Away win: ${p[2].toFixed(1)}%<hr>Over 13.5 goals: ${g[0].toFixed(1)}%<br>Under 13.5 goals: ${g[1].toFixed(1)}%`;
    show("predictionResult",true);
  }catch(e){$("predictionResult").textContent=e.message;show("predictionResult",true);}
};
